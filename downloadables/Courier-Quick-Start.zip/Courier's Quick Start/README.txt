======================
Installation
======================
Use with preffered Mod Manager or drop into data folder and load in Data Files on launcer

======================
Contents
======================
1x Footlocker with some starter gear
	1x 	Hunting Rifle (With some ammo)
	1x 	Courier's Shield (Custom Combat Armour)
	6500x 	Caps

======================
Location
======================
Can be found in Victor's Shack in Goodsprings.
(SPOILER) Given how he follow's you around and is, in general, suspicious I'd argue he stole some of your stuff before Doc Mitchell patches you up.